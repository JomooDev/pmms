SetHttpHandler(exports.httpmanager:createHttpHandler{
	directoryIndex = "index.lsp"
})
