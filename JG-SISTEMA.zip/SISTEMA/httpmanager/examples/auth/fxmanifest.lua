fx_version "cerulean"
game "common"

dependency "httpmanager"

server_only "yes"

server_script "server.lua"
